sudo apt update
sudo apt install nginx -y
sudo service nginx enable
sudo service nginx start